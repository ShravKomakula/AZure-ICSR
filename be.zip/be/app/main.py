from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import xml.etree.ElementTree as ET
from azure.core.credentials import AzureKeyCredential
from azure.ai.textanalytics import TextAnalyticsClient, HealthcareEntityRelation
from azure.ai.formrecognizer import DocumentAnalysisClient
from typing import List, Dict, Union
import tempfile
import os
import json
import uvicorn
from config import *
from schemas.schemas import *

app = FastAPI()

app.add_middleware(
    CORSMiddleware,    allow_origins= ["*"],    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Function to extract narrative from XML
def extract_narrative_from_xml(xml_content):
    try:
        root = ET.fromstring(xml_content)
        narratives = [elem.text for elem in root.iter('narrativeincludeclinical')]
        return narratives
    except Exception as e:
        raise HTTPException(status_code=400, detail="Failed to extract narrative from XML")

text_analytics_client = TextAnalyticsClient(endpoint=LANGUAGE_ENDPOINT, credential=AzureKeyCredential(LANGUAGE_KEY))

# API endpoint to handle file upload and extract narrative
@app.post("/extract-narrative/")
async def extract_narrative(file: UploadFile = File(...)):
    try:
        file_content = await file.read()
        narratives = extract_narrative_from_xml(file_content)
        return {"narratives": narratives}
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to process file")

# API endpoint to process narrative and obtain Text Analytics JSON
@app.post("/process-narrative/")
async def process_narrative(narratives: List[str]):
    try:
        result = text_analytics_client.begin_analyze_healthcare_entities(narratives).result()
        output_data = []
        for doc in result:
            doc_data = {
                "id": f"id__{doc.id}", # Assuming doc.id is available, otherwise generate or retrieve an ID
                "entities": []
            }
            for entity in doc.entities:
                entity_data = {
                    "offset": entity.offset,
                    "length": len(entity.text),
                    "text": entity.text,
                    "category": entity.category,
                    "confidenceScore": entity.confidence_score,
                    "name": entity.text, # Assuming name is the same as text
                    "links": [{"dataSource": ds.name, "id": ds.entity_id} for ds in entity.data_sources] if entity.data_sources else []
                }
                doc_data["entities"].append(entity_data)
            output_data.append(doc_data)
        return TextAnalyticsResponse(documents=output_data)
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to process narrative")

# Initialize DocumentAnalysisClient
document_analysis_client = DocumentAnalysisClient(
    endpoint=DI_ENDPOINT, credential=AzureKeyCredential(DI_KEY)
)

@app.post("/uploadandprocessfile/", response_model=AnalyzeResult)
async def upload_and_process_file(file: UploadFile = File(...)):
    # Save the file to a temporary location
    temp_file_path = os.path.join(tempfile.gettempdir(), file.filename)
    with open(temp_file_path, "wb") as buffer:
        buffer.write(await file.read())
    
    # Read the file content
    with open(temp_file_path, "rb") as file:
        file_content = file.read()
    
    # Begin analyzing document from local file content
    poller = document_analysis_client.begin_analyze_document("prebuilt-layout", file_content)
    result = poller.result()
    
    # Prepare the output data
    output_data = AnalyzeResult(
        apiVersion=result.api_version,
        modelId=result.model_id,
        content=result.content,
        readResults=[],
        pageResults=[]
    )
    
    # Append readResults data to output
    for page in result.pages:
        for word in page.words:
            word_data = WordData(
                content=word.content,
                polygon=word.polygon,
                confidence=word.confidence,
                span={
                    "offset": word.span.offset,
                    "length": word.span.length
                }
            )
            output_data.readResults.append(word_data)
    
    # Return the results
    return output_data

if __name__ == "__main__":
    uvicorn.run(app, port=8023)