LANGUAGE_ENDPOINT='https://icsr-processing.cognitiveservices.azure.com/'
LANGUAGE_KEY='371ed8f444b6448bbf599284d9c430ab'

# AZURE_LANGUAGE_KEY='371ed8f444b6448bbf599284d9c430ab'
# AZURE_LANGUAGE_ENDPOINT='https://icsr-processing.cognitiveservices.azure.com/'

DI_ENDPOINT = "https://documentai-app.cognitiveservices.azure.com/"
DI_KEY = "b4716be00d434909835ec6f4a6de7030"