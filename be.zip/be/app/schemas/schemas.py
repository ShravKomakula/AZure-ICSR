from pydantic import BaseModel
from typing import List, Dict, Union
from fastapi import FastAPI, UploadFile, File, HTTPException
# Pydantic model for narrative extraction request
class NarrativeExtractionRequest(BaseModel):
    file: UploadFile

# Pydantic model for Text Analytics JSON response
class TextAnalyticsResponse(BaseModel):
    documents: List[dict]
    
class FileUploadResponse(BaseModel):
    file_url: str


class WordData(BaseModel):
    content: str
    polygon: List[List[Union[int, float]]] # Adjusted to accept both int and float
    confidence: float
    span: Dict[str, int]


class PageResult(BaseModel):
    readResults: List[WordData]

class AnalyzeResult(BaseModel):
    apiVersion: str
    modelId: str
    content: str
    readResults: List[WordData]
    pageResults: List[PageResult]